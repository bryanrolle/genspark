package test2;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.Homepage;

import java.time.Duration;

public class HomepageBaseTest extends BaseTest {
//add wait method
    @Test
    public void testHomepage() throws InterruptedException {
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage homepage = new Homepage(driver);
        WebDriverWait homepageWait = new WebDriverWait(driver, Duration.ofSeconds(20));
        homepageWait.until(ExpectedConditions.elementToBeClickable(homepage.getHomepage()));
        homepage.getHomepage().click();
    }

    @Test
    public void testCustomerLogin() throws InterruptedException {
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage customer = new Homepage(driver);
        WebDriverWait customerWait = new WebDriverWait(driver, Duration.ofSeconds(20));
        customerWait.until(ExpectedConditions.elementToBeClickable(customer.getCustomerLogin()));
        customer.getCustomerLogin().click();
        customer.getName().click();
        customer.selectName().click();
        customer.loginButton().click();
    }

    @Test
    public void testBankManager() throws InterruptedException {
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage manager = new Homepage(driver);
        WebDriverWait managerWait = new WebDriverWait(driver, Duration.ofSeconds(20));
        managerWait.until(ExpectedConditions.elementToBeClickable(manager.getBankManager()));
        manager.getBankManager().click();
    }

}
