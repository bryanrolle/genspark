package test2;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import pages.Customers_page;
import pages.Homepage;

import java.time.Duration;

public class CustomersBaseTest extends BaseTest {

    @Test
    public void testCustomers() throws InterruptedException {
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage manager = new Homepage(driver);
        Thread.sleep(1000);
        manager.getBankManager().click();
        Customers_page customer = new Customers_page(driver);
        Thread.sleep(1000);
        customer.getCustomers().click();
        Thread.sleep(1000);
        customer.getSearchbar().click();
        Thread.sleep(1000);
        customer.getSearchbar().sendKeys("Harry");
    }
}
