package test2;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import pages.AddCustomer_page;
import pages.Homepage;

import java.time.Duration;

public class AddCustomerBaseTest extends BaseTest {

    @Test
    public void testAddCustomer() throws InterruptedException {
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage manager = new Homepage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(manager.getBankManager()));
        manager.getBankManager().click();
        AddCustomer_page addcustomer = new AddCustomer_page(driver);
        WebDriverWait addcustomerWait = new WebDriverWait(driver, Duration.ofSeconds(20));
        addcustomerWait.until(ExpectedConditions.elementToBeClickable(manager.getBankManager()));
        addcustomer.getAddCustomer().click();
        addcustomer.getFirstname().sendKeys("julius");
        addcustomer.getLastname().sendKeys("randle");
        addcustomer.getPostalcode().sendKeys("10001");
        addcustomer.getAddCustomerbutton().click();
        driver.switchTo().alert().accept();
    }

}
