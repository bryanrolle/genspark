package test2;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.Deposit_page;
import pages.Homepage;

import java.time.Duration;

public class DepositBaseTest extends BaseTest {

    @Test
    public void testDeposit() throws InterruptedException {
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage customer = new Homepage(driver);
        WebDriverWait customerloginWait = new WebDriverWait(driver, Duration.ofSeconds(30));
        customerloginWait.until(ExpectedConditions.elementToBeClickable(customer.getCustomerLogin()));
        customer.getCustomerLogin().click();
        customer.getName().click();
        customer.selectName().click();
        customer.loginButton().click();
        Deposit_page deposit = new Deposit_page(driver);
        deposit.getDeposit().click();
        deposit.getDepositAmount().sendKeys("20");
        deposit.getDepositButton().click();
        deposit.getDepositSuccess().getText();
        Assert.assertEquals(deposit.getDepositSuccess().getText(),"Deposit Successful" );

    }

}
