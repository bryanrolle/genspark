package test2;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import pages.Homepage;
import pages.OpenAccount_page;

import java.time.Duration;

public class OpenAccountBaseTest extends BaseTest {

    @Test
    public void testOpenPoundAccount(){
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage manager = new Homepage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(manager.getBankManager()));
        manager.getBankManager().click();
        OpenAccount_page account = new OpenAccount_page(driver);
        account.getAccount().click();
        account.getCustomer().click();
        account.getSelectName2().click();
        account.getCurrency().click();
        account.getSelectPoundCurrency().click();
        account.getProcessButton().click();
        driver.switchTo().alert().accept();
    }

    @Test
    public void testOpenDollarAccount(){
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage manager = new Homepage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(manager.getBankManager()));
        manager.getBankManager().click();
        OpenAccount_page account = new OpenAccount_page(driver);
        account.getAccount().click();
        account.getCustomer().click();
        account.getSelectName3().click();
        account.getCurrency().click();
        account.getSelectDollarCurrency().click();
        account.getProcessButton().click();
        driver.switchTo().alert().accept();
    }

    @Test
    public void testOpenRupeeAccount(){
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage manager = new Homepage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(manager.getBankManager()));
        manager.getBankManager().click();
        OpenAccount_page account = new OpenAccount_page(driver);
        account.getAccount().click();
        account.getCustomer().click();
        account.getSelectName4().click();
        account.getCurrency().click();
        account.getSelectRupeeCurrecny().click();
        account.getProcessButton().click();
        driver.switchTo().alert().accept();
    }
}
