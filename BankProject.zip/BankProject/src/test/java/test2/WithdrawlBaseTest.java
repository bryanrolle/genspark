package test2;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.Homepage;
import pages.Withdrawl_page;

import java.time.Duration;

public class WithdrawlBaseTest extends BaseTest {

    @Test
    public void testWithDrawl() throws InterruptedException {
        driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
        Homepage customer = new Homepage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(customer.getCustomerLogin()));
        customer.getCustomerLogin().click();
        customer.getName().click();
        customer.selectName().click();
        customer.loginButton().click();
        Withdrawl_page withdrawl = new Withdrawl_page(driver);
        withdrawl.getWithdrawl().click();
        withdrawl.getWithdrawlAmount().sendKeys("20");
        withdrawl.getWithdrawlButton().click();
        withdrawl.getWithdrawlSuccess().getText();
        Assert.assertEquals(withdrawl.getWithdrawlSuccess().getText(),"Transaction Failed. You can not withdraw amount more than the balance.");

    }
}
