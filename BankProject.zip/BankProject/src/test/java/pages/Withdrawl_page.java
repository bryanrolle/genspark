package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Withdrawl_page {

    WebDriver driver;

    public Withdrawl_page(WebDriver driver){
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    @FindBy(xpath = "//button[@ng-click=\"withdrawl()\"]")
    WebElement withdrawlTab;

    @FindBy(xpath = "//input[@type=\"number\"]")
    WebElement withdrawlAmount;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement successButton;

    @FindBy(xpath = "//span[@ng-show=\"message\"]")
    WebElement successMessage;

    // Page Object Model

//    By withdrawlXPath = By.xpath("//button[@ng-click=\"withdrawl()\"]");
//    By withdrawlamountXPath = By.xpath("//input[@type=\"number\"]");
//    By withdrawlbuttonXPath = By.xpath("//button[@type=\"submit\"]");
//    By successmessageXPath = By.xpath("//span[@ng-show=\"message\"]");


    public WebElement getWithdrawl(){
        return withdrawlTab;
    }

    public WebElement getWithdrawlAmount(){
        return  withdrawlAmount;
    }

    public WebElement getWithdrawlButton(){
        return successButton;
    }

    public WebElement getWithdrawlSuccess(){
        return successMessage;
    }
}

