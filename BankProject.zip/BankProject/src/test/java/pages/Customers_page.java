package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Customers_page {


    WebDriver driver;

    public Customers_page(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "//button[@ng-click=\"showCust()\"]")
    WebElement customersTab;

    @FindBy(xpath = "//input[@ng-model=\"searchCustomer\"]")
    WebElement searchbar;

    // Page Object Model

//
//    By customersXPath = By.xpath("//button[@ng-click=\"showCust()\"]");
//    By searchbarXPath = By.xpath("//input[@ng-model=\"searchCustomer\"]");

    public WebElement getCustomers(){
        return customersTab;
    }

    public WebElement getSearchbar(){
        return searchbar;
    }

}