package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Transactions_page {

    WebDriver driver;

    public Transactions_page(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;

    }

    @FindBy(xpath = "//button[@ng-class=\"btnClass1\"]")
    WebElement transactionsTab;

    // Page Object Model

//    By transactionsXPath = By.xpath("//button[@ng-class=\"btnClass1\"]");
//
    public WebElement getTransactions(){
        return transactionsTab;
    }
}

