package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OpenAccount_page {


    WebDriver driver;

    public OpenAccount_page(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    @FindBy(xpath = "//button[@ng-click=\"openAccount()\"]")
    WebElement openAccount;

    @FindBy(xpath = "//select[@name=\"userSelect\"]")
    WebElement customer;

    @FindBy(xpath = "//select[@name=\"currency\"]")
    WebElement currency;

    @FindBy(xpath = "//option[@value=\"2\"]")
    WebElement selectName2;

    @FindBy(xpath = "//option[@value=\"3\"]")
    WebElement selectName3;

    @FindBy(xpath = "//option[@value=\"4\"]")
    WebElement selectName4;

    @FindBy(xpath = "//option[@value=\"Rupee\"]")
    WebElement selectrupeeCurrecny;

    @FindBy(xpath = "//option[@value=\"Pound\"]")
    WebElement selectpoundCurrency;

    @FindBy(xpath = "//option[@value=\"Dollar\"]")
    WebElement selectdollarCurency;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement processButton;


    // Page Object Model

//    By openaccountXPath = By.xpath("//button[@ng-click=\"openAccount()\"]");
//    By customerXPath = By.xpath("//select[@name=\"userSelect\"]");
//    By currencyXPath = By.xpath("//select[@name=\"currency\"]");
//    By selectnameXPath = By.xpath("//option[@value=\"2\"]");
//    By selectcurrencyXPath = By.xpath("//option[@value=\"Pound\"]");
//    By proccessbuttonXPath = By.xpath("//button[@type=\"submit\"]");

    public WebElement getAccount(){
        return openAccount;
    }

    public WebElement getCustomer(){
        return customer;
    }

    public WebElement getCurrency(){
        return currency;
    }

    public WebElement getSelectName2(){
        return selectName2;
    }

    public WebElement getSelectName3(){
        return selectName3;
    }

    public WebElement getSelectName4(){
        return selectName4;
    }

    public WebElement getSelectRupeeCurrecny(){
        return selectrupeeCurrecny;
    }

    public WebElement getSelectPoundCurrency(){
        return selectpoundCurrency;
    }

    public WebElement getSelectDollarCurrency(){
        return selectdollarCurency;
    }

    public WebElement getProcessButton(){
        return processButton;
    }

}
