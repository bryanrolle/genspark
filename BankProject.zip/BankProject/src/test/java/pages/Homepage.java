package pages;

import com.fasterxml.jackson.databind.ser.Serializers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import test2.HomepageBaseTest;

public class Homepage {

    WebDriver driver;

        public Homepage(WebDriver driver){
            PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    @FindBy(xpath = "//button[@ng-click=\"home()\"]")
    WebElement homeButton;

    @FindBy(xpath = "//button[@ng-click=\"customer()\"]")
    WebElement customerLogin;

    @FindBy(xpath = "//button[@ng-click=\"manager()\"]")
    WebElement bankManager;

    @FindBy(xpath = "//select[@name=\"userSelect\"]")
    WebElement select;

    @FindBy(xpath = "//option[@value=\"3\"]")
    WebElement name;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement loginButton;


    // Page Object Model

//    By xPath = By.xpath("//button[@ng-click=\"home()\"]");
//    By xPath1 = By.xpath("//button[@ng-click=\"customer()\"]");
//    By xPath2 = By.xpath("//button[@ng-click=\"manager()\"]");
//    By selectXPath = By.xpath("//select[@name=\"userSelect\"]");
//    By nameXPATH = By.xpath("//option[@value=\"3\"]");
//    By loginXPATH = By.xpath("//button[@type=\"submit\"]");
//


    public WebElement getHomepage() {
        return homeButton;
    }

    public WebElement getCustomerLogin() {
        return customerLogin;
    }

    public WebElement getName() {
        return name;
    }

    public WebElement selectName(){
        return select;
    }

    public WebElement loginButton(){
        return loginButton;
    }

    public WebElement getBankManager() {
        return  bankManager;
    }
}

