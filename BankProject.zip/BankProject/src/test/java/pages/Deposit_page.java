package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Deposit_page {

    WebDriver driver;

    public Deposit_page(WebDriver driver){
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    @FindBy(xpath = "//button[@ng-click=\"deposit()\"]")
    WebElement deposit;

    @FindBy(xpath = "//input[@type=\"number\"]")
    WebElement amount;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement depositButton;

    @FindBy(xpath = "//span[@ng-show=\"message\"]")
    WebElement successMessage;

    // Page Object Model

//    By depositXPath = By.xpath("//button[@ng-click=\"deposit()\"]");
//    By amountXPath = By.xpath("//input[@type=\"number\"]");
//    By depositbuttonXPath = By.xpath("//button[@type=\"submit\"]");
//    By successmessageXPath = By.xpath("//span[@ng-show=\"message\"]");

    public WebElement getDeposit() {
        return deposit;
    }

    public WebElement getDepositAmount(){
        return amount;
    }

    public WebElement getDepositButton(){
        return depositButton;
    }

    public WebElement getDepositSuccess(){
        return successMessage;
    }
}



