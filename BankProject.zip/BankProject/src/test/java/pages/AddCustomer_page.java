package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddCustomer_page {

    WebDriver driver;

    public AddCustomer_page(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    @FindBy(xpath = "//button[@ng-class=\"btnClass1\"]" )
    WebElement addCustomer;

    @FindBy(xpath = "//input[@type=\"text\"][1]")
    WebElement firstName;

    @FindBy(xpath = "//input[@ng-model=\"lName\"]")
    WebElement lastName;

    @FindBy(xpath = "//input[@ng-model=\"postCd\"]")
    WebElement postalCode;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement addcustomerButton;


    // Page Object Model

//    By addcustomerXPath = By.xpath("//button[@ng-class=\"btnClass1\"]");
//    By firstnameXPath =By.xpath("//input[@type=\"text\"][1]");
//    By lastnameXPath =By.xpath("//input[@ng-model=\"lName\"]");
//    By postalcodeXPath =By.xpath("//input[@ng-model=\"postCd\"]");
//    By addcustomerButtonXPath =By.xpath("//button[@type=\"submit\"]");

    public WebElement getAddCustomer(){
        return addCustomer;
    }

    public WebElement getFirstname(){
        return firstName;
    }

    public WebElement getLastname(){
        return lastName;
    }

    public WebElement getPostalcode(){
        return postalCode;
    }

    public WebElement getAddCustomerbutton(){
        return addcustomerButton;
    }

}